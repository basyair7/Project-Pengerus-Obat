// DSX-07 Lite Motor L293D
// By Ahul07
// 2020

#include "DSXLite.h"
#include "Arduino.h"

// Declaration Library for Pin Board
DSX_pinMotors::DSX_pinMotors(int motorA, int motorB, int motorC, int motorD){
  dinamo1=motorA;
  dinamo2=motorB;
  dinamo3=motorC;
  dinamo4=motorD;
}

// PinMode for void setup
void DSX_pinMotors::pinMotors(){
  pinMode(dinamo1,OUTPUT);
  pinMode(dinamo2,OUTPUT);
  pinMode(dinamo3,OUTPUT);
  pinMode(dinamo4,OUTPUT);
}

// if the motors is forward
void DSX_pinMotors::forward(){
  digitalWrite(dinamo1, HIGH);
  digitalWrite(dinamo2, LOW);
  digitalWrite(dinamo3, HIGH);
  digitalWrite(dinamo4, LOW);
}

// if the motors is backward
void DSX_pinMotors::backward(){
  digitalWrite(dinamo1, LOW);
  digitalWrite(dinamo2, HIGH);
  digitalWrite(dinamo3, LOW);
  digitalWrite(dinamo4, HIGH);
}

// if the motors turns left
void DSX_pinMotors::turnLeft(){
  digitalWrite(dinamo1, HIGH);
  digitalWrite(dinamo2, LOW);
  digitalWrite(dinamo3, LOW);
  digitalWrite(dinamo4, HIGH);
}

// if the motors turns right
void DSX_pinMotors::turnRight(){
  digitalWrite(dinamo1, LOW);
  digitalWrite(dinamo2, HIGH);
  digitalWrite(dinamo3, HIGH);
  digitalWrite(dinamo4, LOW);
}

// if the motor stops
void DSX_pinMotors::stops(){
  digitalWrite(dinamo1, LOW);
  digitalWrite(dinamo2, LOW);
  digitalWrite(dinamo3, LOW);
  digitalWrite(dinamo4, LOW);
}
